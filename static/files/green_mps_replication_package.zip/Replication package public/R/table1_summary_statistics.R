
source("R/setup.R")
source("R/functions.R")

load("output/european_data_mps.RData")

# Remove NAs
data <- data %>% 
  filter(!(is.na(emission_sales_est))) %>%
  filter(!(is.na(size_mcap))) %>%
  filter(!(is.na(bookmarket))) %>%
  filter(!(is.na(book_leverage))) %>%
  filter(!(is.na(profitability))) %>%
  filter(!(is.na(rev_growth))) %>%
  filter(!(is.na(investment))) %>%
  filter(!(is.na(logppen)))

# Panel A and B: Environmental performance/Firm-level controls

# Annual variables
annual_data <- data %>% mutate(emission_mktcap_est = emission_mktcap_est * 1000) %>%
  select(RIC, Year, emission_sales_est, emission_mktcap_est,
         log_emissions_est, 
         escores, emissionscores, size_mcap, bookmarket,
         book_leverage, profitability, rev_growth, investment, logppen,
         cash_asset1, tangibility1, Beta, cashflow_asset1, age) %>%
  distinct()

df <- tibble(Names = names(annual_data)[-c(1:2)],
  Mean = annual_data %>% select(-c(RIC, Year)) %>%
  apply(2, mean, na.rm = TRUE) %>% round(2),
  SD = annual_data %>% select(-c(RIC, Year)) %>%
  apply(2, sd, na.rm = TRUE) %>% round(2),
  Min = annual_data %>% select(-c(RIC, Year)) %>%
  apply(2, min, na.rm = TRUE) %>% round(2),
  q25 = annual_data %>% select(-c(RIC, Year)) %>%
  apply(2, quantile, prob = 0.25, na.rm = TRUE) %>% round(2),
  Median = annual_data %>% select(-c(RIC, Year)) %>%
    apply(2, median, na.rm = TRUE) %>% round(2),
  q75 = annual_data %>% select(-c(RIC, Year)) %>%
  apply(2, quantile, prob = 0.75, na.rm = TRUE) %>% round(2),
  Max = annual_data %>% select(-c(RIC, Year)) %>%
  apply(2, max, na.rm = TRUE) %>% round(2),
  Obs = annual_data %>% select(-c(RIC, Year)) %>%
    apply(2, function(x) length(na.omit(x)))) %>%
  as.data.frame()

panelAB <- data.frame(
  Names = c("Emission Intensity", "Emission Market cap", "Log emission", 
            "E-score", "Emission score", "Size", "Book-market", "Leverage", 
            "Profitability", "Rev. growth", "Investment", "Log PP&E", "Liquidity", 
            "Tangibility", "Beta", "Cash flow", "Age"),
  Mean = sprintf("%.2f", df$Mean),
  SD = sprintf("%.2f", df$SD),
  Min = sprintf("%.2f", df$Min),
  q25 = sprintf("%.2f", df$q25),
  Median = sprintf("%.2f", df$Median),
  q75 = sprintf("%.2f", df$q75),
  Max = sprintf("%.2f", df$Max),
  Obs = df$Obs
)
panelAB
# Print the LaTeX code with custom formatting
#print(xtable(panelAB), include.rownames = FALSE, sanitize.text.function = identity)

# Panel C: Returns
daily_ret <- data %>% select(RIC, date, mps_tot, ret) %>% na.omit() %>%
  distinct()

panelC <- data.frame(
  Names = "Daily return",
  Mean = sprintf("%.2f", mean(daily_ret $ ret)),
  SD = sprintf("%.2f", sd(daily_ret $ ret)),
  Min = sprintf("%.2f", min(daily_ret $ ret)),
  q25 = sprintf("%.2f", quantile(daily_ret $ ret, probs = 0.25)),
  Median = sprintf("%.2f", quantile(daily_ret $ ret, probs = 0.5)),
  q75 = sprintf("%.2f", quantile(daily_ret $ ret, probs = 0.75)),
  Max = sprintf("%.2f", max(daily_ret $ ret)),
  Obs = nrow(daily_ret)
)

#print(xtable(PanelC), include.rownames = FALSE, sanitize.text.function = identity)

# Panel D: Monetary policy surprises
surp <- data %>%
  select(date, OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  mutate(MP_median = MP_median * 100) %>%
  unique() %>%
  filter(!(is.na(OIS_3M_tot)))

df2 <- tibble(
Names = colnames(surp)[-1],
Mean = surp %>%
  select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  na.omit() %>% apply(2, mean) %>% round(2),
SD = surp %>% select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  na.omit() %>% apply(2, sd) %>% round(2),
Min = surp %>% select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  na.omit() %>% apply(2, min) %>% round(2),
q25 = surp %>% select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  na.omit() %>% apply(2, quantile, prob = 0.25),
Median = surp %>% select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  na.omit() %>% apply(2, quantile, prob = 0.5) %>% round(2),
q75 = surp %>% select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  na.omit() %>% apply(2, quantile, prob = 0.75),
Max = surp %>% select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  na.omit() %>% apply(2, max) %>% round(2),
Obs = surp %>% select(OIS_3M_tot, OIS_1Y, mps_tot, Target, FG, Krusell, MP_median) %>%
  apply(2, function(x){length(na.omit(x))}))%>%
  as.data.frame()

panelD <- data.frame(
  Names = c("3-months OIS", "1-Year OIS", "PC", 
            "Target", "FG", "KTW", "JK"),
  Mean = sprintf("%.2f", df2$Mean),
  SD = sprintf("%.2f", df2$SD),
  Min = sprintf("%.2f", df2$Min),
  q25 = sprintf("%.2f", df2$q25),
  Median = sprintf("%.2f", df2$Median),
  q75 = sprintf("%.2f", df2$q75),
  Max = sprintf("%.2f", df2$Max),
  Obs = df2$Obs
)

# Print in Latex
#print(xtable(PanelD), include.rownames = FALSE, sanitize.text.function = identity)

panelAB
panelC
panelD
