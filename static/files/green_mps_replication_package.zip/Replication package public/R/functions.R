constr_portfolios <- function(DF, char, ret, weight, h) {
  # Convert character inputs to symbols
  char_sym <- sym(char)
  ret_sym <- sym(ret)
  weight_sym <- sym(weight)
  
  # Filter out rows where the column specified by char_sym is NA
  DF <- DF %>% 
    filter(!is.na(!!char_sym)) %>%
    group_by(Year) %>%
    mutate(decile = ntile(!!char_sym, n = h)) %>%
    ungroup()
  
  # Summarise data within groups
  res <- DF %>% 
    group_by(date, decile) %>%
    summarise(ret_ew = mean(!!ret_sym, na.rm = TRUE),
              ret_vw = weighted.mean(!!ret_sym, coalesce(!!weight_sym, 0), na.rm = TRUE),
              char_mean = mean(!!char_sym, na.rm = TRUE),
              char_median = median(!!char_sym, na.rm = TRUE),
              char_max = max(!!char_sym, na.rm = TRUE),
              char_min = min(!!char_sym, na.rm = TRUE),
              firms_count = sum(!is.na(!!char_sym)),
              .groups = "drop_last") %>%
    ungroup()
  
  return(res)
}

# Functions from github package hfdshocks
# See https://github.com/martinbaumgaertner/hfdshocks
rotate <- function(data, crisis_date = "2008-09-04", window = "release", 
                   extended = FALSE) 
{
  ois_matrix <- data %>% dplyr::select(dplyr::starts_with("ois")) %>% 
    as.matrix()
  date_vector <- data %>% dplyr::pull(date)
  fm <- factor_model(ois_matrix)
  scale <- apply(fm$factors, 2, sd)
  factors <- sweep(fm$factors, 2, scale, "/")[, 1:3]
  idx_pre <- 1:(which(date_vector == as.POSIXlt(crisis_date, 
                                                tz = "UTC")) - 1)
  id <- list(fa = factors[idx_pre, ], l = (fm$loadings[, 1:3] * 
                                             scale[1:3]))
  con <- function(x) {
    loading <- id$l
    f <- NULL
    f <- rbind(f, x[1]^2 + x[4]^2 + x[7]^2 - 1)
    f <- rbind(f, x[2]^2 + x[5]^2 + x[8]^2 - 1)
    f <- rbind(f, x[3]^2 + x[6]^2 + x[9]^2 - 1)
    f <- rbind(f, x[1] * x[2] + x[4] * x[5] + x[7] * x[8] - 
                 0)
    f <- rbind(f, x[1] * x[3] + x[4] * x[6] + x[7] * x[9] - 
                 0)
    f <- rbind(f, x[2] * x[3] + x[5] * x[6] + x[8] * x[9] - 
                 0)
    f <- rbind(f, x[4] * loading[1, 1] + x[5] * loading[1, 
                                                        2] + x[6] * loading[1, 3] - 0)
    f <- rbind(f, x[7] * loading[1, 1] + x[8] * loading[1, 
                                                        2] + x[9] * loading[1, 3] - 0)
    return(list(ceq = f, c = NULL))
  }
  obj <- function(x) {
    u <- matrix(c(x[1], x[2], x[3], x[4], x[5], x[6], x[7], 
                  x[8], x[9]), nrow = 3)
    factor_idx <- if (extended && window == "release") 
      2
    else 3
    xx <- id$fa %*% u[, factor_idx]
    out <- 0.5 * t(xx) %*% xx/length(xx)
    as.numeric(out)
  }
  sol <- NlcOptim::solnl(c(diag(3)), objfun = obj, confun = con)
  rotate_factors <- factors %*% matrix(sol$par, nrow = 3) %>% 
    dplyr::as_tibble(.name_repair = ~vctrs::vec_as_names(..., 
                                                         repair = "unique", quiet = TRUE))
  rotate_factors <- rename_and_scale_factors(rotate_factors, 
                                             data, ois_matrix, window, extended)
  factors_scaled <- dplyr::bind_cols(data %>% dplyr::select(date), 
                                     rotate_factors)
  return(factors_scaled)
}

factor_model <- function(z, center = TRUE, scale_z = FALSE) {
  t_n <- nrow(z)
  nn <- ncol(z)
  if (center == TRUE) {
    mean_z <- colMeans(z)
  } else {
    mean_z <- rep(0, nn)
  }
  if (scale_z == TRUE) {
    sd_z <- apply(z, 2, sd)
  } else {
    sd_z <- rep(1, nn)
  }
  
  x <- sweep(sweep(z, 2, mean_z), 2, sd_z, "/")
  
  ev <- eigen(t(x) %*% x, only.values = FALSE)
  neg <- which(ev$values < 0)
  
  if (!length(neg) == 0) {
    break
  }
  lamda <- ev$values
  sigma <- sqrt(lamda / t_n)
  v_k <- sigma^2 / sum(sigma^2)
  lambda <- sqrt(nn) * ev$vectors
  fa <- x %*% lambda / nn
  
  return(list(factors = fa, loadings = lambda, eigenvalues = lamda, center = mean_z, scale = sd_z, data = z))
}

rename_and_scale_factors <- function(rotate_factors, data, ois_matrix, window, extended) {
  if (window == "release") {
    if (extended) {
      rotate_factors <- rotate_factors %>%
        dplyr::select(1:2) %>%
        dplyr::rename(target = 1, qe = 2)
      
      full <- bind_cols(data %>% dplyr::select(date), rotate_factors, ois_matrix %>% dplyr::as_tibble(.))
      scale_1 <- coef(lm(ois_1m ~ target, data = full))[2]
      scale_2 <- coef(lm(ois_10y ~ qe, data = full))[2]
      
      rotate_factors <- rotate_factors %>%
        dplyr::mutate(target = target * scale_1, qe = qe * scale_2)
    } else {
      rotate_factors <- rotate_factors %>%
        dplyr::select(1) %>%
        dplyr::rename(target = 1)
      
      full <- dplyr::bind_cols(data %>% dplyr::select(date), rotate_factors, ois_matrix %>% dplyr::as_tibble(.))
      scale_1 <- coef(lm(ois_1m ~ target, data = full))[2]
      
      rotate_factors <- rotate_factors %>%
        dplyr::mutate(target = target * scale_1)
    }
  } else {
    rotate_factors <- rotate_factors %>%
      dplyr::select(1:3) %>%
      dplyr::rename(timing = 1, fg = 2, qe = 3)
    
    full <- bind_cols(data %>% dplyr::select(date), rotate_factors, ois_matrix %>% dplyr::as_tibble(.))
    scale_4 <- coef(lm(ois_6m ~ timing, data = full))[2]
    scale_5 <- coef(lm(ois_2y ~ fg, data = full))[2]
    scale_6 <- coef(lm(ois_10y ~ qe, data = full))[2]
    
    rotate_factors <- rotate_factors %>%
      dplyr::mutate(timing = timing * scale_4, fg = fg * scale_5, qe = qe * scale_6)
  }
  return(rotate_factors)
}