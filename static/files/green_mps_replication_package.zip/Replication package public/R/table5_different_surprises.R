
source("R/setup.R")
source("R/functions.R")

load("output/european_data_mps.RData")

data <- data %>% mutate(
  OIS_3M_tot = OIS_3M_tot / 100,
  OIS_1Y = OIS_1Y / 100,
  mps_tot = mps_tot / 100,
  Target = Target / 100,
  FG = FG / 100,
  Krusell = Krusell / 100,
  emission_sales_est_std = scale(emission_sales_est),
  OIS_3M_emission_sales_est = OIS_3M_tot * emission_sales_est_std,
  OIS_1Y_emission_sales_est = OIS_1Y * emission_sales_est_std,
  mps_tot_emission_sales_est = mps_tot * emission_sales_est_std,
  Target_emission_sales_est = Target * emission_sales_est_std,
  FG_emission_sales_est = FG * emission_sales_est_std,
  Krusell_emission_sales_est = Krusell * emission_sales_est_std,
  MP_median_emission_sales_est =  MP_median * emission_sales_est_std)

# Panel A
mods1 <- list(felm(ret ~ OIS_3M_tot + OIS_3M_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num, data),
             felm(ret ~ OIS_1Y + OIS_1Y_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num, data),
             felm(ret ~ mps_tot + mps_tot_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num, data),
             felm(ret ~ Target + Target_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num, data),
             felm(ret ~ FG + FG_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num, data),
             felm(ret ~ Krusell + Krusell_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num, data),
             felm(ret ~ MP_median + MP_median_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num, data))

calcSEs2 <- function(mod) sqrt(diag(vcovCL(mod, type = "HC0", 
                                           cluster = ~ dateday_num + RIC_num,
                                           fix = TRUE)))
rob_se1 <- lapply(mods1, calcSEs2)

stargazer(mods1, digits = 2, header = FALSE, se = rob_se1,
          no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
          type = "text", omit = c("size_mcap", "bookmarket", "book_leverage", 
                                   "profitability", "rev_growth", "investment", 
                                   "logppen"))

# coef_print <- sapply(mods1, function(x) coef(x)[2])
# coef_print <- paste(round(coef_print, 2), collapse = "&")
# coef_print <- gsub("-", "\\$-\\$", coef_print)
# 
# se_print <- sapply(mods1, function(x) calcSEs2(x)[2])
# paste(round(se_print, 2), collapse = "&")

# Panel B
mods2 <- list(felm(ret ~ OIS_3M_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num + day_industry_fe, data),
             felm(ret ~ OIS_1Y_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num + day_industry_fe, data),
             felm(ret ~ mps_tot_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num + day_industry_fe, data),
             felm(ret ~ Target_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num + day_industry_fe, data),
             felm(ret ~ FG_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num + day_industry_fe, data),
             felm(ret ~ Krusell_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num + day_industry_fe, data),
             felm(ret ~ MP_median_emission_sales_est + emission_sales_est_std + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment + 
                    logppen | RIC_num + day_industry_fe, data))

calcSEs2 <- function(mod) sqrt(diag(vcovCL(mod, type = "HC0", 
                                           cluster = ~ dateday_num + RIC_num,
                                           fix = TRUE)))
rob_se2 <- lapply(mods2, calcSEs2)

stargazer(mods2, digits = 2, header = FALSE, se = rob_se2,
          no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
          type = "text", omit = c("size_mcap", "bookmarket", "book_leverage", 
                                  "profitability", "rev_growth", "investment", 
                                  "logppen"))

# coef_print <- sapply(mods2, function(x) coef(x)[1])
# coef_print <- paste(round(coef_print, 2), collapse = "&")
# coef_print <- gsub("-", "\\$-\\$", coef_print)
# 
# se_print <- sapply(mods2, function(x) calcSEs2(x)[1])
# paste(round(se_print, 2), collapse = "&")


