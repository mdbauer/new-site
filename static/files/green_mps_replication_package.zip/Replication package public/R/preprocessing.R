
source("R/setup.R")
source("R/functions.R")

# ---------------------- Stock market data ----------------------

# Read prices
price <- read_excel("data/european_prices.xlsx", sheet = "Values",
                    col_types = c("date", rep("numeric", 2527))) %>% 
  arrange(Name)

print(price)

price <- price %>% rename(Date = Name) %>%
  pivot_longer(cols = -Date, names_to = "stocks", values_to = "price") %>%
  mutate(date = as.Date(Date)) %>% select(-Date)

# Calculate simple returns
price <- price %>% arrange(stocks, date) %>% group_by(stocks) %>%
  mutate(ret = (price - dplyr::lag(price)) / dplyr::lag(price),
         ret2 = (dplyr::lead(price, 1) - dplyr::lag(price)) / dplyr::lag(price),
         ret3 = (dplyr::lead(price, 2) - dplyr::lag(price)) / dplyr::lag(price)) %>%
  ungroup() %>% arrange(stocks)

# Load market Cap daily
mktcap <- read_excel("data/european_mktcap.xlsx", sheet = "Value",
                     col_types = c("date", rep("numeric", 2527))) %>% 
  arrange(Name)

mktcap <- mktcap %>% rename(Date = Name) %>%
  pivot_longer(cols = -Date, names_to = "stocks", values_to = "mktcap") %>%
  mutate(date = as.Date(Date)) %>% select(-Date)

mktcap <- mktcap %>% group_by(stocks) %>%
  mutate(mktcap_lag = dplyr::lag(mktcap)) %>%
  ungroup()

# Merge prices and mktcap
price <- price %>%
  inner_join(mktcap, by = c("stocks", "date"))

length(unique(price $ stocks))

# ---------------------- Emissions and Balance Sheet Data  ----------------------

# First set of variables:
accounting_data <- read_csv("data/accouting_data.csv")

length(unique(accounting_data $ RIC))

# Filters. Exchange market?
accounting_data <- accounting_data %>% filter(`STOCK TYPE` == "EQ") %>%
  filter(`TRCS DESCRIPTION` == "Ordinary Shares")

# Add annual price
price_ann <- price %>%
  mutate(Year = year(date)) %>%
  select(Year, stocks, ann_price = price) %>%
  group_by(Year, stocks) %>% slice_tail() %>%
  ungroup()

accounting_data <- accounting_data %>% inner_join(price_ann, 
                                                  by = c("stocks", "Year"), multiple = "all")

length(unique(accounting_data $ RIC))

# Calculate emission variables
accounting_data <- accounting_data %>%
  mutate(log_emissions = ifelse(CO2Total > 0, log(CO2Total), NA),
         log_emissions = ifelse(is.infinite(log_emissions), NA, log_emissions),
         log_emissions_est = ifelse(EstimatedCO2 > 0, log(EstimatedCO2), NA),
         log_emissions_est = ifelse(is.infinite(log_emissions_est), NA, log_emissions_est),
         emission_sales = CO2Total / TotRev,
         emission_sales = ifelse(is.infinite(emission_sales), NA, emission_sales),
         emission_sales_est = EstimatedCO2 / TotRev,
         emission_sales_est = ifelse(is.infinite(emission_sales_est), NA, emission_sales_est),
         emission_mktcap = CO2Total / MktCap_yearly,
         emission_mktcap = ifelse(is.infinite(emission_mktcap), NA, emission_mktcap),
         emission_mktcap_est = EstimatedCO2 / MktCap_yearly,
         emission_mktcap_est = ifelse(is.infinite(emission_mktcap_est), NA, emission_mktcap_est))

# Calculate accouting variables
accounting_data <- accounting_data %>%
  mutate(size_asset = log(TotAssets),
         size_asset = ifelse(is.infinite(size_asset), NA, size_asset),
         size_mcap = log(MktCap_yearly),
         size_mcap = ifelse(is.infinite(size_mcap), NA, size_mcap),
         bookmarket = BookEq / MktCap_yearly,
         bookmarket = ifelse(is.infinite(bookmarket), NA, bookmarket),
         profitability = GrossProfit * 1000000 / TotAssets,
         profitability = ifelse(is.infinite(profitability), NA, profitability),
         TotRev = ifelse(TotRev <= 0, NA, TotRev),
         rev_growth = log(TotRev) - dplyr::lag(log(TotRev)),
         rev_growth = ifelse(is.infinite(rev_growth), NA, rev_growth),
         book_leverage = TotDebt / TotAssets,
         int_cov = IntRateCov,
         ppen = ifelse(ppen <= 0, NA, ppen),
         logppen = log(ppen),
         investment = capx / TotAssets,
         investment = ifelse(is.infinite(investment), NA, investment),
         tangibility1 = ppen / (ppen + int1),
         tangibility1 = ifelse(is.infinite(tangibility1), NA, tangibility1),
         tangibility2 = ppen / (ppen + int2),
         tangibility2 = ifelse(is.infinite(tangibility2), NA, tangibility2),
         cash_asset1 = cash1 / TotAssets,
         cash_asset1 = ifelse(is.infinite(cash_asset1), NA, cash_asset1),
         cash_asset2 = cash2 / TotAssets,
         cash_asset2 = ifelse(is.infinite(cash_asset2), NA, cash_asset2),
         priceearnings = ann_price / eps,
         priceearnings = ifelse(is.infinite(priceearnings), NA, priceearnings),
         ppen_asset = ppen / TotAssets,
         ppen_asset = ifelse(is.infinite(ppen_asset), NA, ppen_asset),
         cashflow_asset1 = op_income / TotAssets,
         cashflow_asset1 = ifelse(is.infinite(cashflow_asset1), NA, cashflow_asset1),
         cashflow_asset2 = (op_income + Depr) / TotAssets,
         cashflow_asset2 = ifelse(is.infinite(cashflow_asset2), NA, cashflow_asset2),
         age = Year - year(IPODate))

# ---- 2 years lag ------
# Merge emission and prices
accounting_data <- accounting_data %>%
  mutate(merge_year = Year + 2)

# Prepare for merge. Add zero lower bound and age
price <- price %>% mutate(merge_year = year(date)) %>%
  mutate(zlbdummy = ifelse(between(year(date), 2016, 2022), 1, 0))

data <- accounting_data %>% inner_join(price, by = c("stocks", "merge_year"), multiple = "all")

# ---- 18 months lag ------
# Merge emission and prices

#price <- price %>% mutate(merge_year = ifelse(month(date) >= 7, year(date) - 1, year(date) - 2))

#data <- accounting_data %>% mutate(merge_year = Year) %>%
#  inner_join(price, by = c("stocks", "merge_year"), multiple = "all")

length(unique(data $ RIC))

# Housekeeping

data <- data %>%
  select(-c('DATASTREAM CODE', 'TRCS DESCRIPTION',
            'ISIN CODE', 'BOURSE NAME', 'STOCK TYPE'))

# ---------------------- Filters ----------------------
# Only stocks in euro
data <- data %>% filter(CURRENCY == "E")

length(unique(data $ RIC))

data <- data %>% filter(year(date) > 2011) # Start year for stock market data

# Getting rid of penny stocks defined as
# Firms that had price lower than 1$ during the last five years
# Ince and Porter (2006 p. 473)
data <- data %>% group_by(RIC) %>%
  filter(all(price > 1 | is.na(price))) %>% ungroup()

length(unique(data $ RIC))

# Key words
# See Griffin, Kelly, Nardari (2010, Table B.2)
data <- data %>% 
  filter(!(str_detect(stocks, "REIT"))) %>%
  filter(!(str_detect(stocks, "INV.TST."))) %>%
  filter(!(str_detect(stocks, "INV.TRUST"))) %>%
  filter(!(str_detect(stocks, "PREFERRED"))) %>%
  filter(!(str_detect(stocks, "DELIST"))) %>%
  filter(!(str_detect(stocks, "RLST")))

length(unique(data $ RIC)) 

# Only firms with positive book to market are allowed
data <- data %>% filter(bookmarket > 0)

length(unique(data $ RIC))
# ---------------------- Industries ----------------------
data <- data %>% rename(sic = 'SIC CODE 1')

# Fama and French 12
data <- data %>% mutate(sic = as.numeric(sic)) %>%
  mutate(ind_name = ifelse(between(sic, 100, 999) | between(sic, 2000,2399) | between(sic, 2700,2749) |
                             between(sic, 2770,2799) | between(sic, 3100,3199) | between(sic, 3940,3989), "NoDur",
                           ifelse(between(sic, 2500,2519) | between(sic, 2590,2599) | between(sic, 3630,3659) |
                                    between(sic, 3710,3711) |  between(sic, 3714,3714) |  between(sic, 3716,3716) |
                                    between(sic, 3750,3751) | between(sic, 3792,3792) | between(sic, 3900,3939) | between(sic, 3990,3999), "Durbl",
                                  ifelse(between(sic, 2520,2589) | between(sic, 2600,2699) | between(sic, 2750,2769) |
                                           between(sic, 3000,3099) | between(sic, 3200,3569) | between(sic, 3580,3629) |
                                           between(sic, 3700,3709) | between(sic, 3712,3713) | between(sic, 3715,3715) |
                                           between(sic, 3717,3749) | between(sic, 3752,3791) | between(sic, 3793,3799) |
                                           between(sic, 3830,3839) | between(sic, 3860,3899), "Manuf",
                                         ifelse(between(sic, 1200,1399) | between(sic, 2900,2999) , "Energy",
                                                ifelse(between(sic, 2800,2829) | between(sic, 2840,2899) , "Chems",
                                                       ifelse(between(sic, 3570,3579) | between(sic, 3660,3692) |
                                                                between(sic, 3694,3699) | between(sic, 3810,3829) |
                                                                between(sic, 7370,7379), "BusEq",
                                                              ifelse(between(sic, 4800,4899), "Telcm",
                                                                     ifelse(between(sic, 4900,4949), "Utils",
                                                                            ifelse(between(sic, 5000,5999) | between(sic, 7200,7299) |
                                                                                     between(sic, 7600,7699), "Shops",
                                                                                   ifelse(between(sic, 2830,2839) | between(sic, 3693,3693) |
                                                                                            between(sic, 3840,3859) | between(sic, 8000,8099), "Health",
                                                                                          ifelse(between(sic, 6000, 6999), "Finance", "Others"))))))))))))


data <- data %>% mutate(ind_num12 = ifelse(ind_name == "NoDur", 1,
                                           ifelse(ind_name == "Durbl", 2,
                                                  ifelse(ind_name == "Manuf", 3,
                                                         ifelse(ind_name == "Energy", 4,
                                                                ifelse(ind_name == "Chems", 5,
                                                                       ifelse(ind_name == "BusEq", 6,
                                                                              ifelse(ind_name == "Telcm", 7,
                                                                                     ifelse(ind_name == "Utils", 8,
                                                                                            ifelse(ind_name == "Shops", 9,
                                                                                                   ifelse(ind_name == "Health", 10,
                                                                                                          ifelse(ind_name == "Finance", 11, 12))))))))))))


# More granular industry definition (2 digits SIC)
data <- data %>% mutate(ind_num_sic2digits = as.numeric(substr(sic, 1, 2)))

# ---------------------- Prepare Fixed Effects ----------------------

# Monthly fixed effects
data <- data %>% 
  mutate(yearmonth = as.yearmon(date))
temp <- tibble(yearmonth = unique(data $ yearmonth),
               date_num = 1:length(unique(data $ yearmonth)))
data <- data %>% left_join(temp, by = "yearmonth")

# Daily fixed effects
temp <- tibble(date = unique(data $ date),
               dateday_num = 1:length(unique(data $ date)))
data <- data %>% left_join(temp, by = "date")

# Firm fixed effects
temp <- tibble(RIC = unique(data $ RIC),
               RIC_num = 1:length(unique(data $ RIC)))
data <- data %>% left_join(temp, by = "RIC")

# Country fixed effects
data <- data %>% rename(country = `GEOG DESC OF LSTNG`)
temp <- tibble(country = unique(data $ country),
               country_num = 1:length(unique(data $ country)))
data <- data %>% left_join(temp, by = "country")

# Day X industry fixed effects
day_industry_fe <- data %>% select(dateday_num, ind_num_sic2digits) %>%
  distinct() %>% mutate(day_industry_fe = row_number())

data <- data %>% left_join(day_industry_fe, 
                           by = c("dateday_num", "ind_num_sic2digits"))

# Day X country fixed effects
day_country_fe <- data %>% select(dateday_num, country_num) %>%
  distinct() %>% mutate(day_country_fe = row_number())

data <- data %>% left_join(day_country_fe, 
                           by = c("dateday_num", "country_num"))

# ---------------------- Winsorize ----------------------

# Emissions
data <- data %>%
  group_by(RIC) %>%
  mutate(log_emissions = ifelse(log_emissions > quantile(log_emissions, na.rm = TRUE, probs = 0.99), 
                         quantile(log_emissions, na.rm = TRUE, probs = 0.99), 
                         ifelse(log_emissions < quantile(log_emissions, na.rm = TRUE, probs = 0.01),
                                quantile(log_emissions, na.rm = TRUE, probs = 0.01), log_emissions)),
         log_emissions_est = ifelse(log_emissions_est > quantile(log_emissions_est, na.rm = TRUE, probs = 0.99), 
                     quantile(log_emissions_est, na.rm = TRUE, probs = 0.99), 
                     ifelse(log_emissions_est < quantile(log_emissions_est, na.rm = TRUE, probs = 0.01),
                            quantile(log_emissions_est, na.rm = TRUE, probs = 0.01), log_emissions_est)),
         emission_sales = ifelse(emission_sales > quantile(emission_sales, na.rm = TRUE, probs = 0.99), 
                      quantile(emission_sales, na.rm = TRUE, probs = 0.99), 
                      ifelse(emission_sales < quantile(emission_sales, na.rm = TRUE, probs = 0.01),
                             quantile(emission_sales, na.rm = TRUE, probs = 0.01), emission_sales)),
         emission_sales_est = ifelse(emission_sales_est > quantile(emission_sales_est, na.rm = TRUE, probs = 0.99), 
                        quantile(emission_sales_est, na.rm = TRUE, probs = 0.99), 
                        ifelse(emission_sales_est < quantile(emission_sales_est, na.rm = TRUE, probs = 0.01),
                               quantile(emission_sales_est, na.rm = TRUE, probs = 0.01), emission_sales_est)),
         emission_mktcap = ifelse(emission_mktcap > quantile(emission_mktcap, na.rm = TRUE, probs = 0.99), 
                      quantile(emission_mktcap, na.rm = TRUE, probs = 0.99), 
                      ifelse(emission_mktcap < quantile(emission_mktcap, na.rm = TRUE, probs = 0.01),
                             quantile(emission_mktcap, na.rm = TRUE, probs = 0.01), emission_mktcap)),
         emission_mktcap_est = ifelse(emission_mktcap_est > quantile(emission_mktcap_est, na.rm = TRUE, probs = 0.99), 
                      quantile(emission_mktcap_est, na.rm = TRUE, probs = 0.99), 
                      ifelse(emission_mktcap_est < quantile(emission_mktcap_est, na.rm = TRUE, probs = 0.01),
                             quantile(emission_mktcap_est, na.rm = TRUE, probs = 0.01), emission_mktcap_est))) %>%
  ungroup()


# Controls
data <- data %>%
  group_by(RIC) %>%
  mutate(size_asset = ifelse(size_asset > quantile(size_asset, na.rm = TRUE, probs = 0.99), 
                                quantile(size_asset, na.rm = TRUE, probs = 0.99), 
                                ifelse(size_asset < quantile(size_asset, na.rm = TRUE, probs = 0.01),
                                       quantile(size_asset, na.rm = TRUE, probs = 0.01), size_asset)),
         size_mcap = ifelse(size_mcap > quantile(size_mcap, na.rm = TRUE, probs = 0.99), 
                                    quantile(size_mcap, na.rm = TRUE, probs = 0.99), 
                                    ifelse(size_mcap < quantile(size_mcap, na.rm = TRUE, probs = 0.01),
                                           quantile(size_mcap, na.rm = TRUE, probs = 0.01), size_mcap)),
         bookmarket = ifelse(bookmarket > quantile(bookmarket, na.rm = TRUE, probs = 0.99), 
                                 quantile(bookmarket, na.rm = TRUE, probs = 0.99), 
                                 ifelse(bookmarket < quantile(bookmarket, na.rm = TRUE, probs = 0.01),
                                        quantile(bookmarket, na.rm = TRUE, probs = 0.01), bookmarket)),
         book_leverage = ifelse(book_leverage > quantile(book_leverage, na.rm = TRUE, probs = 0.99), 
                                     quantile(book_leverage, na.rm = TRUE, probs = 0.99), 
                                     ifelse(book_leverage < quantile(book_leverage, na.rm = TRUE, probs = 0.01),
                                            quantile(book_leverage, na.rm = TRUE, probs = 0.01), book_leverage)),
         profitability = ifelse(profitability > quantile(profitability, na.rm = TRUE, probs = 0.99), 
                                  quantile(profitability, na.rm = TRUE, probs = 0.99), 
                                  ifelse(profitability < quantile(profitability, na.rm = TRUE, probs = 0.01),
                                         quantile(profitability, na.rm = TRUE, probs = 0.01), profitability)),
         rev_growth = ifelse(rev_growth > quantile(rev_growth, na.rm = TRUE, probs = 0.99), 
                                      quantile(rev_growth, na.rm = TRUE, probs = 0.99), 
                                      ifelse(rev_growth < quantile(rev_growth, na.rm = TRUE, probs = 0.01),
                                             quantile(rev_growth, na.rm = TRUE, probs = 0.01), rev_growth)),
         divpershare = ifelse(divpershare > quantile(divpershare, na.rm = TRUE, probs = 0.99), 
                                         quantile(divpershare, na.rm = TRUE, probs = 0.99), 
                                         ifelse(divpershare < quantile(divpershare, na.rm = TRUE, probs = 0.01),
                                                quantile(divpershare, na.rm = TRUE, probs = 0.01), divpershare)),
         logppen = ifelse(logppen > quantile(logppen, na.rm = TRUE, probs = 0.99), 
                              quantile(logppen, na.rm = TRUE, probs = 0.99), 
                              ifelse(logppen < quantile(logppen, na.rm = TRUE, probs = 0.01),
                                     quantile(logppen, na.rm = TRUE, probs = 0.01), logppen)),
         investment = ifelse(investment > quantile(investment, na.rm = TRUE, probs = 0.99), 
                              quantile(investment, na.rm = TRUE, probs = 0.99), 
                              ifelse(investment < quantile(investment, na.rm = TRUE, probs = 0.01),
                                     quantile(investment, na.rm = TRUE, probs = 0.01), investment)),
         tangibility1 = ifelse(tangibility1 > quantile(tangibility1, na.rm = TRUE, probs = 0.99), 
                              quantile(tangibility1, na.rm = TRUE, probs = 0.99), 
                              ifelse(tangibility1 < quantile(tangibility1, na.rm = TRUE, probs = 0.01),
                                     quantile(tangibility1, na.rm = TRUE, probs = 0.01), tangibility1)),
         tangibility2 = ifelse(tangibility2 > quantile(tangibility2, na.rm = TRUE, probs = 0.99), 
                               quantile(tangibility2, na.rm = TRUE, probs = 0.99), 
                               ifelse(tangibility2 < quantile(tangibility2, na.rm = TRUE, probs = 0.01),
                                      quantile(tangibility2, na.rm = TRUE, probs = 0.01), tangibility2)),
         cash_asset1 = ifelse(cash_asset1 > quantile(cash_asset1, na.rm = TRUE, probs = 0.99), 
                               quantile(cash_asset1, na.rm = TRUE, probs = 0.99), 
                               ifelse(cash_asset1 < quantile(cash_asset1, na.rm = TRUE, probs = 0.01),
                                      quantile(cash_asset1, na.rm = TRUE, probs = 0.01), cash_asset1)),
         cash_asset2 = ifelse(cash_asset2 > quantile(cash_asset2, na.rm = TRUE, probs = 0.99), 
                               quantile(cash_asset2, na.rm = TRUE, probs = 0.99), 
                               ifelse(cash_asset2 < quantile(cash_asset2, na.rm = TRUE, probs = 0.01),
                                      quantile(cash_asset2, na.rm = TRUE, probs = 0.01), cash_asset2)),
         priceearnings = ifelse(priceearnings > quantile(priceearnings, na.rm = TRUE, probs = 0.99), 
                              quantile(priceearnings, na.rm = TRUE, probs = 0.99), 
                              ifelse(priceearnings < quantile(priceearnings, na.rm = TRUE, probs = 0.01),
                                     quantile(priceearnings, na.rm = TRUE, probs = 0.01), priceearnings)),
         ppen_asset = ifelse(ppen_asset > quantile(ppen_asset, na.rm = TRUE, probs = 0.99), 
                              quantile(ppen_asset, na.rm = TRUE, probs = 0.99), 
                              ifelse(ppen_asset < quantile(ppen_asset, na.rm = TRUE, probs = 0.01),
                                     quantile(ppen_asset, na.rm = TRUE, probs = 0.01), ppen_asset)),
         cashflow_asset1 = ifelse(cashflow_asset1 > quantile(cashflow_asset1, na.rm = TRUE, probs = 0.99), 
                              quantile(cashflow_asset1, na.rm = TRUE, probs = 0.99), 
                              ifelse(cashflow_asset1 < quantile(cashflow_asset1, na.rm = TRUE, probs = 0.01),
                                     quantile(cashflow_asset1, na.rm = TRUE, probs = 0.01), cashflow_asset1)),
         cashflow_asset2 = ifelse(cashflow_asset2 > quantile(cashflow_asset2, na.rm = TRUE, probs = 0.99), 
                              quantile(cashflow_asset2, na.rm = TRUE, probs = 0.99), 
                              ifelse(cashflow_asset2 < quantile(cashflow_asset2, na.rm = TRUE, probs = 0.01),
                                     quantile(cashflow_asset2, na.rm = TRUE, probs = 0.01), cashflow_asset2))) %>%
  ungroup()

# Adjust some variables
data <- data %>% mutate(ret = ret * 100,
                        ret2 = ret2 * 100,
                        ret3 = ret3 * 100,
                        emission_sales_est = emission_sales_est * 1000,
                        emission_sales = emission_sales * 1000)

# ------- Construct quintile portfolios -----------

port_emission <- constr_portfolios(DF = data, char = "log_emissions_est",
                                   ret = "ret", weight = "mktcap_lag", h = 5)

port_emission_sales <- constr_portfolios(DF = data, char = "emission_sales_est",
                                         ret = "ret", weight = "mktcap_lag", h = 5)

port_emission_mktcap <- constr_portfolios(DF = data, char = "emission_mktcap_est",
                                          ret = "ret", weight = "mktcap_lag", h = 5)

port_escores <- constr_portfolios(DF = data, char = "escores",
                                  ret = "ret", weight = "mktcap_lag", h = 5)

port_emissionscores <- constr_portfolios(DF = data, char = "emissionscores",
                                         ret = "ret", weight = "mktcap_lag", h = 5)

# ------------- Add monetary policy surprises ------------

# Load monetary policy surprises
load("output/euro_surprises.RData")

# Load Jaroncinski and Karadi Data
jk <- read_csv("data/shocks_ecb_mpd_me_d.csv")

surprises <- euro_surprises %>% full_join(jk, by = "date")

# ECB announcement day fixed effects
temp <- tibble(date = unique(surprises $ date),
               ecb_announc_fe = 1:length(unique(surprises $ date)))

surprises <- surprises %>% left_join(temp, by = "date")

# Merge with firm level data
data <- data %>% left_join(surprises, by = "date")

save("data", file = "output/european_data_mps.RData")

# Merge with quintile portfolios
port_emission <- port_emission %>% left_join(surprises, by = "date")
port_emission_sales <- port_emission_sales %>% left_join(surprises, by = "date")
port_emission_mktcap <- port_emission_mktcap %>% left_join(surprises, by = "date")
port_escores <- port_escores %>% left_join(surprises, by = "date") 
port_emissionscores <- port_emissionscores %>% left_join(surprises, by = "date")

save(port_emission, port_emission_sales,
     port_emission_mktcap, port_escores, port_emissionscores, file = "output/euro_port_mps.RData")

