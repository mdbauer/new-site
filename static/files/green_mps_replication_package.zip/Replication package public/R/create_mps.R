source("R/setup.R")
source("R/functions.R")

## ----------- Load surprises -------------------------------------------------

# Produce 3m, 1y, PC, and Krusell 
eampd_m <- read_excel("data/Dataset_EA-MPD.xlsx", sheet = 4) %>%
  mutate(date = as.Date(date)) %>%
  filter(year(date) > 2001)

# Exclude dates according to Altavilla et al. (2019)
exclude_date <- as_date(c("2001-09-17",
                          "2008-10-08",
                          "2008-11-06",
                          "2011-08-04"
))

# OIS
X_tot  <- eampd_m %>% 
  filter(!(date %in% exclude_date)) %>% 
  mutate(Y5 = coalesce(OIS_5Y, DE5Y),
         Y10 = coalesce(OIS_10Y, DE10Y)) %>%
  select(date, OIS_1M, OIS_3M, OIS_6M, OIS_1Y, OIS_2Y, Y5, Y10)

## 1st PC
X_tot $ mps <- prcomp(select(X_tot, -date), center = FALSE, scale = TRUE) $ x[,1]

# Scale factor
b <- lm(OIS_1Y ~ 0 + mps, X_tot) $ coef
X_tot $ mps <- X_tot $ mps * b

X_tot <- X_tot %>% select(date, OIS_3M_tot = OIS_3M, mps_tot = mps, OIS_1Y)

euro_surprises <- X_tot %>%
  full_join(eampd_m %>%
  select(date, STOXX50_tot = STOXX50), by = "date")

# Create Krusell surprise
euro_surprises <- euro_surprises %>%
  mutate(Krusell = ifelse(OIS_3M_tot > 0 & STOXX50_tot > 0, NA, OIS_3M_tot),
         Krusell = ifelse(OIS_3M_tot < 0 & STOXX50_tot < 0, NA, Krusell)) %>%
  arrange(date)

# Produce Target and FG surprises from Altavilla et al. (2019)
eampd_r <- read_excel("data/Dataset_EA-MPD.xlsx", sheet = "Press Release Window") %>%
  mutate(date = as.Date(date)) %>%
  filter(year(date) > 2001)

eampd_c <- read_excel("data/Dataset_EA-MPD.xlsx", sheet = "Press Conference Window") %>%
  mutate(date = as.Date(date)) %>%
  filter(year(date) > 2001)

# Target is created from release window
X_rel <- eampd_r %>% 
  filter(!(date %in% exclude_date)) %>% 
  mutate(OIS_5Y = coalesce(OIS_5Y, DE5Y),
         OIS_10Y = coalesce(OIS_10Y, DE10Y)) %>%
  dplyr::select(date, OIS_1M, OIS_3M, OIS_6M, OIS_1Y, OIS_2Y, OIS_5Y, OIS_10Y)

names(X_rel) <- tolower(names(X_rel))

Target <- rotate(X_rel)

# Forward guidance is created from conference window
X_con <- eampd_c %>% 
  filter(!(date %in% exclude_date)) %>% 
  mutate(OIS_5Y = coalesce(OIS_5Y, DE5Y),
         OIS_10Y = coalesce(OIS_10Y, DE10Y)) %>%
  dplyr::select(date, OIS_1M, OIS_3M, OIS_6M, OIS_1Y, OIS_2Y, OIS_5Y, OIS_10Y) %>%
  na.omit()

names(X_con) <- tolower(names(X_con))

FG <- rotate(X_con, window = "conference")

altavillaetal <- Target %>%
  inner_join(FG, by = "date") %>%
  select(date, Target = target, FG = fg)

euro_surprises <- euro_surprises %>%
  left_join(altavillaetal, by = "date")

save(euro_surprises, file = "output/euro_surprises.RData")
