
source("R/setup.R")
source("R/functions.R")

load("output/european_data_mps.RData")

# Prepare interaction terms
data <- data %>% mutate(
  OIS_1Y = OIS_1Y / 100,
  emission_sales_est_std = scale(emission_sales_est),
  mps_emission_sales_est = OIS_1Y * emission_sales_est_std)

# Main regression 
  mods <- list(felm(ret ~ OIS_1Y + emission_sales_est_std +
                  size_mcap + bookmarket + book_leverage + 
                  profitability + rev_growth + investment + 
                  logppen | RIC_num, data),
               felm(ret ~ OIS_1Y + emission_sales_est_std + 
                      mps_emission_sales_est +
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num, data),
               felm(ret ~ emission_sales_est_std + 
                      mps_emission_sales_est +
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num + dateday_num, data),
               felm(ret ~ emission_sales_est_std + 
                      mps_emission_sales_est +
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num + day_industry_fe, data),
               felm(ret ~ emission_sales_est_std + mps_emission_sales_est + 
                    size_mcap + bookmarket + book_leverage + 
                    profitability + rev_growth + investment  + 
                    logppen | RIC_num + day_country_fe, data))

calcSEs2 <- function(mod) sqrt(diag(vcovCL(mod, type = "HC0", cluster = ~ RIC_num + dateday_num,
                                         fix = TRUE)))
     
rob_se <- lapply(mods, calcSEs2)

stargazer(mods, digits = 2, header = FALSE, se = rob_se,
          no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
          type = "text", keep = c("OIS_1Y", "mps_emission_sales_est",
                                  "emission_sales_est"),
          order = c(1,3,2),
          add.lines = list(#c("Controls", "N", "N", "Y", "Y", "Y", "Y"),
                           c("Firm FE", "Y", "Y", "Y", "Y", "Y"),
                           c("Time FE", "N", "N", "Y", "N", "N"),
                           #c("Industry FE", "N", "N", "N", "Y", "N", "Y"),
                           c("Industry X Time FE", "N", "N", "N", "Y", "N"),
                           c("Country X Time FE", "N", "N", "N", "N", "Y")),
          covariate.labels = c("mps", "mps times g", "Emission intensity"))



