
source("R/setup.R") # Library and working directory
source("R/functions.R")

# Read indexes
data <- read_csv("data/index_data.csv")

# Calculate returns and standardize
data <- data %>% arrange(date) %>%
  pivot_longer(cols = colnames(data)[-1], names_to = "index", values_to = "price") %>%
  group_by(index) %>% mutate(retex = (price - dplyr::lag(price)) / dplyr::lag(price) * 100) %>% 
  na.omit() %>% ungroup()

data <- data %>%
  group_by(index) %>%
  mutate(retex = as.numeric(scale(retex))) %>%
  ungroup() %>%
  filter(year(date) > 2009)

# Select indexes
data <- data %>% select(date, index, retex) %>%
  pivot_wider(names_from = "index", values_from = "retex")

green <- data %>%
    select(c("date", "Wilderhill Clean Energy", #"Nasdaq Clean Edge Green Energy",
           "S&P Global Clean Energy",
           "ISE Global Wind Energy",
           "MAC Global Solar Energy")) %>% na.omit()

brown <- data %>%
  select(c("date", "S&P 500 Integrated Oil & Gas TR",
           "FTSE All World Oil & Gas & Coal Index, USD",
           "STOXX Europe 600 Oil & Gas Price EUR")) %>% na.omit()

# Principal components
green1 <- green %>% select(-date)
brown1 <- brown %>% select(-date)
cov_green <- t(as.matrix(green1)) %*% as.matrix(green1)
cov_brown <- t(as.matrix(brown1)) %*% as.matrix(brown1)
pca_green <- as.matrix(green1) %*% eigen(cov_green) $ vectors[,1] / sum(eigen(cov_green) $ vectors[,1])
pca_brown <- as.matrix(brown1) %*% eigen(cov_brown) $ vectors[,1] / sum(eigen(cov_brown) $ vectors[,1])

green <- green %>% mutate(green_factor = as.numeric(pca_green))
brown <- brown %>% mutate(brown_factor = as.numeric(pca_brown))

data1 <- green %>% inner_join(brown, by = "date") %>%
  mutate(BMG = brown_factor - green_factor)

# Load monetary policy surprises
load("output/euro_surprises.RData")

jk <- read_csv("data/shocks_ecb_mpd_me_d.csv")

# Merge everything
data1 <- data1 %>% left_join(euro_surprises, by = "date") %>%
  left_join(jk, by = "date") %>%
  filter(year(date) > 2009) %>%
  mutate(OIS_1Y = OIS_1Y / 100,
         OIS_3M_tot = OIS_3M_tot / 100) %>%
  select(date, green_factor, brown_factor, BMG, OIS_3M_tot, OIS_1Y, MP_median) %>% na.omit()

# Pooled regression: Table 9
mods <- list(lm(brown_factor ~ OIS_3M_tot, data1),
             lm(green_factor ~ OIS_3M_tot, data1),
             lm(BMG ~ OIS_3M_tot, data1),
             lm(brown_factor ~ OIS_1Y, data1),
             lm(green_factor ~ OIS_1Y, data1),
             lm(BMG ~ OIS_1Y, data1),
             lm(brown_factor ~ MP_median, data1),
             lm(green_factor ~ MP_median, data1),
             lm(BMG ~ MP_median, data1))

calcSEs1 <- function(mod) sqrt(diag(vcovHC(mod)))

rob_se <- lapply(mods, calcSEs1)

stargazer(mods, digits = 2, header = FALSE, se = rob_se,
          no.space = TRUE, omit.stat = c("f", "ser", "rsq", "N"), 
          type = "text")

