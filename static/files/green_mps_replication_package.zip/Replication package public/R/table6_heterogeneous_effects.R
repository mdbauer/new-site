
source("R/setup.R")
source("R/functions.R")

load("output/european_data_mps.RData")

data <- data %>% mutate(
ppen_asset = ppen / TotAssets,
ppen_asset = ifelse(is.infinite(ppen_asset), NA, ppen_asset))

# Prepare interaction terms
data <- data %>% mutate(
  age = as.numeric(age),
  OIS_1Y = OIS_1Y / 100,
  emission_sales_est_std = scale(emission_sales_est),
  mps_emission_sales_est = OIS_1Y * emission_sales_est_std,
  size_mcap_std = scale(size_mcap),
  OIS_1Y_tot_mcap = OIS_1Y * size_mcap_std,
  bookmarket_std = scale(bookmarket),
  OIS_1Y_tot_bookmarket = OIS_1Y * bookmarket_std,
  book_leverage_std = scale(book_leverage),
  OIS_1Y_tot_book_leverage = OIS_1Y * book_leverage_std,
  profitability_std = scale(profitability),
  OIS_1Y_tot_profitability = OIS_1Y * profitability_std,
  tangibility1_std = scale(tangibility1),
  OIS_1Y_tot_tangibility1 = OIS_1Y * tangibility1_std,
  cash_asset1_std = scale(cash_asset1),
  OIS_1Y_tot_cash_asset1 = OIS_1Y * cash_asset1_std,
  age_std = scale(age),
  OIS_1Y_tot_age = OIS_1Y * age_std,
  Beta_std = scale(Beta),
  OIS_1Y_tot_beta = OIS_1Y * Beta_std,
  cashflow_asset1_std = scale(cashflow_asset1),
  OIS_1Y_tot_cashflow_asset1 = OIS_1Y * cashflow_asset1_std,
  investment_std = scale(investment),
  OIS_1Y_tot_investment = OIS_1Y * investment_std,
  ppen_asset_std = scale(ppen_asset),
  OIS_1Y_tot_ppen_asset_std = OIS_1Y * ppen_asset_std,
  logppen_std = scale(logppen),
  rev_growth_std = scale(rev_growth))

# Main regression 
  mods <- list(
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std + 
                    profitability_std + rev_growth_std + investment_std + 
                    logppen_std + OIS_1Y_tot_mcap | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std + 
                    profitability_std + rev_growth_std + investment_std + 
                    logppen_std + OIS_1Y_tot_bookmarket | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std + 
                    profitability_std + rev_growth_std + investment_std + 
                    logppen_std + OIS_1Y_tot_book_leverage | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std + 
                    profitability_std + rev_growth_std + investment_std + 
                    logppen_std + OIS_1Y_tot_profitability | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std + 
                    profitability_std + rev_growth_std + investment_std + tangibility1_std + 
                    logppen_std + OIS_1Y_tot_tangibility1 | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std +
                    profitability_std + rev_growth_std + investment_std + cash_asset1_std +
                    logppen_std + OIS_1Y_tot_cash_asset1 | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std +
                    profitability_std + rev_growth_std + investment_std + 
                    logppen_std + OIS_1Y_tot_age | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std +
                    profitability_std + rev_growth_std + investment_std + 
                    logppen_std + OIS_1Y_tot_beta | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est +
                    size_mcap_std + bookmarket_std + book_leverage_std +
                    profitability_std + rev_growth_std + investment_std + cashflow_asset1_std +
                    logppen_std + OIS_1Y_tot_cashflow_asset1 | RIC_num + day_industry_fe, data),
             felm(ret ~ #emission_sales_est_std + mps_emission_sales_est + 
                    rev_growth_std + investment_std + logppen_std +
                    size_mcap_std + OIS_1Y_tot_mcap +
                    bookmarket_std + OIS_1Y_tot_bookmarket + 
                    book_leverage_std + OIS_1Y_tot_book_leverage +
                    profitability_std + OIS_1Y_tot_profitability +
                    cashflow_asset1_std + OIS_1Y_tot_cashflow_asset1 +
                    OIS_1Y_tot_beta + OIS_1Y_tot_age +
                    #tangibility1_std + OIS_1Y_tot_tangibility1 + 
                    cash_asset1_std + OIS_1Y_tot_cash_asset1 | RIC_num + day_industry_fe, data))

calcSEs2 <- function(mod) sqrt(diag(vcovCL(mod, type = "HC0",
                                             cluster = ~ RIC_num + dateday_num,
                                             fix = TRUE)))
rob_se <- lapply(mods, calcSEs2)

stargazer(mods, digits = 2, header = FALSE, se = rob_se,
          no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
          type = "text", keep = c("mps_emission_sales_est",
                                  "OIS_1Y_tot_mcap",
                                  "OIS_1Y_tot_book_leverage",
                                  "OIS_1Y_tot_bookmarket",
                                  "OIS_1Y_tot_profitability",
                                  "OIS_1Y_tot_tangibility1",
                                  "OIS_1Y_tot_cash_asset1",
                                  "OIS_1Y_tot_age",
                                  "OIS_1Y_tot_beta",
                                  "OIS_1Y_tot_invest",
                                  "OIS_1Y_tot_ppen",
                                  "OIS_1Y_tot_op_income",
                                  "OIS_1Y_tot_cashflow_asset1"))

