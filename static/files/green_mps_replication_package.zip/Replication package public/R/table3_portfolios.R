
source("R/setup.R")
source("R/functions.R")

load("output/european_data_mps.RData")

# Prepare interaction terms
data <- data %>% mutate(
  OIS_1Y = OIS_1Y / 100,
  emission_sales_est_std = scale(emission_sales_est),
  mps_emission_sales_est = OIS_1Y * emission_sales_est_std)

data <- data %>% group_by(Year) %>%
  mutate(quintile = ntile(emission_sales_est, 5)) %>%
  ungroup()

# Main regression 
  mods1 <- list(felm(ret ~ OIS_1Y + 
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num, data = data %>% filter(quintile == 1)),
               felm(ret ~ OIS_1Y + 
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num, data = data %>% filter(quintile == 2)),
               felm(ret ~ OIS_1Y + 
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num, data = data %>% filter(quintile == 3)),
               felm(ret ~ OIS_1Y + 
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num, data = data %>% filter(quintile == 4)),
               felm(ret ~ OIS_1Y + 
                      size_mcap + bookmarket + book_leverage + 
                      profitability + rev_growth + investment + 
                      logppen | RIC_num, data = data %>% filter(quintile == 5)))


calcSEs2 <- function(mod) sqrt(diag(vcovCL(mod, type = "HC0", cluster = ~ RIC_num + dateday_num,
                                           fix = TRUE)))

rob_se1 <- lapply(mods1, calcSEs2)

# Portfolio
double_sorted_port <- data %>% 
  filter(!(is.na(emission_sales_est))) %>%
  filter(!(is.na(size_mcap))) %>%
  group_by(Year) %>%
  mutate(quantile_size = ntile(size_mcap, n = 5)) %>%
  ungroup() %>%
  group_by(Year, quantile_size) %>%
  mutate(quantile_emission = ntile(emission_sales_est, n = 5)) %>%
  ungroup()

double_sorted_port <- double_sorted_port %>% 
  group_by(date, quantile_size, quantile_emission) %>%
  summarise(ret_ew = mean(ret, na.rm = TRUE),
            ret_vw = weighted.mean(ret, coalesce(mktcap_lag, 0), na.rm = TRUE),
            .groups = "drop_last") %>%
  ungroup()

double_sorted_port <- double_sorted_port %>% filter(quantile_size %in% c(1, 5) & quantile_emission %in% c(1, 5)) %>%
  select(date, quantile_size, quantile_emission, ret_ew, ret_vw) %>%
  group_by(date, quantile_emission) %>%
  summarise(ret_ew = mean(ret_ew),
            ret_vw = mean(ret_vw)) %>% ungroup()

surp <- data %>% select(date, OIS_1Y, pc1) %>%
  na.omit() %>% unique()

double_sorted_port <- double_sorted_port %>% 
  pivot_wider(names_from = "quantile_emission", 
              values_from = c("ret_ew", "ret_vw")) %>%
  mutate(BMG_ew = ret_ew_5 - ret_ew_1,
         BMG_vw = ret_vw_5 - ret_vw_1) %>%
  select(date, BMG_ew, BMG_vw) %>% 
  inner_join(surp, by = "date")

double_sorted_port <- double_sorted_port %>% mutate(Year = year(date),
                                    Month = month(date))

port_emission <- constr_portfolios(DF = data, 
                                   char = "emission_sales_est",
                                   ret = "ret", weight = "mktcap_lag", h = 5)

port_emission <- port_emission %>% filter(decile %in% c(1, 5)) %>%
  select(date, decile, ret_ew, ret_vw) %>%
  pivot_wider(names_from = "decile", values_from = c("ret_ew", "ret_vw")) %>%
  mutate(BMG_ew = ret_ew_5 - ret_ew_1,
         BMG_vw = ret_vw_5 - ret_vw_1)
  
port_emission <- port_emission %>% left_join(surp, by = "date")

mods2 <- list(lm(BMG_ew ~ OIS_1Y, port_emission),
             lm(BMG_ew ~ OIS_1Y, double_sorted_port),
             felm(BMG_ew ~ OIS_1Y | Year + Month, double_sorted_port),
             lm(BMG_vw ~ OIS_1Y, port_emission),
             lm(BMG_vw ~ OIS_1Y, double_sorted_port),
             felm(BMG_vw ~ OIS_1Y | Year + Month, double_sorted_port))

calcSEs1 <- function(mod) sqrt(diag(vcovHC(mod, type = "HC0")))

rob_se2 <- lapply(mods2, calcSEs1)

stargazer(mods1, digits = 2, header = FALSE, se = rob_se1,
          no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
          type = "text", keep = c("OIS_1Y"))

stargazer(mods2, digits = 2, header = FALSE, se = rob_se2,
          no.space = TRUE, omit.stat = c("f", "adj.rsq", "ser"), 
          type = "text",
          omit = c("Constant"))