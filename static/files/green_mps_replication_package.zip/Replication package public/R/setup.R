
## List of packages to check
pkgs <- c("readxl", "dplyr", "lubridate", "tidyr", "stringr", "rlang",
 "sandwich", "stargazer", "readr", "lfe", "DescTools", "purrr", "ggplot2",
 "zoo", "xtable", "gridExtra")

# Get list of installed packages
installed_packages <- installed.packages()

# Find missing packages
missing_packages <- pkgs[!(pkgs %in% rownames(installed_packages))]

# Install missing packages
if (length(missing_packages) > 0) {
  install.packages(missing_packages)
}

## Load the packages
library(dplyr)
library(lubridate)
library(tidyr)
library(stringr)
library(rlang)
library(readxl)
library(sandwich)
library(stargazer)
library(readr)
library(lfe)
library(DescTools)
library(purrr)
library(ggplot2)
library(zoo)
library(xtable)
library(gridExtra)
