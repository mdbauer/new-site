  
  source("R/setup.R")
  source("R/functions.R")
  
  load("output/euro_port_mps.RData")
  
  #port_emission_mktcap, port_emission_sales
  port <- port_emission_sales %>%
    mutate(OIS_1Y = OIS_1Y / 100,
           OIS_3M_tot = OIS_3M_tot / 100) %>% 
    rename(quintile = decile)
  
  port <- port %>% select(date, ret_vw, quintile, OIS_3M_tot, OIS_1Y) %>%
    filter(!(is.na(OIS_1Y))) %>%
    filter(quintile %in% c(1, 5)) %>%
    pivot_wider(names_from = "quintile",
                values_from = "ret_vw") %>%
    mutate(BMG = `5` - `1`,
           color = ifelse(year(date) %in% 2022:2023, "period2", "period1"))
    
  p1 <- port %>%
    ggplot(aes(x = OIS_3M_tot, y = BMG, color = color)) + 
    geom_point(size = 2) + 
    geom_smooth(aes(group = 1), method = "lm", 
                formula = y ~ x, se = FALSE, color = "blue") +
    scale_color_manual(values = c("black", "red")) +
    labs(y = "Brown-minus-green return", 
         x = "Change in three-month OIS rate") +
    theme_bw() +
    theme(legend.position = "none")
  
  #p1 #(6.4 X 4.3)
  
  p2 <- port %>%
    ggplot(aes(x = OIS_1Y, y = BMG, color = color)) +
    geom_point(size = 2) +
    geom_smooth(aes(group = 1), method = "lm",
                formula = y ~ x, se = FALSE, color = "blue") +
    scale_color_manual(values = c("black", "red")) +
    labs(y = "Brown-minus-green return",
         x = "Change in one-year OIS rate") +
    theme_bw() +
    theme(legend.position = "none")
  
  #p2
  
  grid.arrange(p1, p2, ncol = 2) # 9.2 X 4
