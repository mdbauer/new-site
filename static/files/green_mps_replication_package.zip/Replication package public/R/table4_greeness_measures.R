  
  source("R/setup.R")
  source("R/functions.R")
  
  load("output/european_data_mps.RData")
  
  # Prepare interaction terms and standardize
  data <- data %>% mutate(
    OIS_1Y = OIS_1Y / 100,
    emission_sales_est_std = scale(emission_sales_est),
    mps_emission_sales_est = OIS_1Y * emission_sales_est_std,
    emission_sales_std = scale(emission_sales),
    mps_emission_sales = OIS_1Y * emission_sales_std,
    log_emissions_est_std = scale(log_emissions_est),
    log_emissions_std = scale(log_emissions),
    mps_log_emissions_est = OIS_1Y * log_emissions_est_std,
    mps_log_emissions = OIS_1Y * log_emissions_std,
    emissionscores_std = scale(emissionscores),
    mps_emissionscores = OIS_1Y * emissionscores_std,
    escores_std = scale(escores),
    mps_escores = OIS_1Y * escores_std,
    emission_mktcap_est_std = scale(emission_mktcap_est),
    mps_emission_mktcap_est = OIS_1Y * emission_mktcap_est_std,
    emission_mktcap_std = scale(emission_mktcap),
    mps_emission_mktcap = OIS_1Y * emission_mktcap_std)
  
  # Main regression 
  mods1 <- list(felm(ret ~ emission_sales_est_std + 
                      mps_emission_sales_est + size_mcap + profitability + 
                      bookmarket + book_leverage + rev_growth +
                      logppen + investment | RIC_num + day_industry_fe, data),
               felm(ret ~ emission_mktcap_est_std + mps_emission_mktcap_est
                    + size_mcap + investment + profitability + 
                      bookmarket + book_leverage + rev_growth + logppen 
                    | RIC_num + day_industry_fe, data),
               felm(ret ~ log_emissions_est_std + mps_log_emissions_est + 
                      size_mcap + investment + profitability + 
                      bookmarket + book_leverage + rev_growth + logppen | 
                      RIC_num + day_industry_fe, data))
    
  mods2 <- list(felm(ret ~ emission_sales_std + mps_emission_sales 
                      + size_mcap + investment + profitability + 
                        bookmarket + book_leverage + rev_growth + logppen 
                      | RIC_num + day_industry_fe, data),
                felm(ret ~ emission_mktcap_std + mps_emission_mktcap + profitability + 
                       bookmarket + size_mcap + investment + book_leverage + rev_growth + 
                       logppen | RIC_num + day_industry_fe, data),
               felm(ret ~ log_emissions_std + mps_log_emissions 
                    + size_mcap + investment + profitability + 
                      bookmarket + book_leverage + rev_growth +
                      logppen | RIC_num + day_industry_fe, data))
  
  
  mods3 <- list(felm(ret ~ emissionscores_std + mps_emissionscores 
                    + size_mcap + investment + profitability + 
                      bookmarket + book_leverage + rev_growth + logppen 
                    | RIC_num + day_industry_fe, data),
               felm(ret ~ escores_std + mps_escores + profitability + bookmarket +
                      size_mcap + investment + book_leverage + rev_growth + 
                      logppen | RIC_num + day_industry_fe, data))
  
  calcSEs2 <- function(mod) sqrt(diag(vcovCL(mod, type = "HC0", 
                                             cluster = ~ RIC_num + dateday_num,
                                             fix = TRUE)))
  
  
  #coef_print <- sapply(mods1, function(x) coef(x)[2])
  #se_print <- sapply(mods1, function(x) calcSEs2(x)[2])
  
  #paste(round(coef_print, 2), collapse = "&")
  #paste(round(se_print, 2), collapse = "&")
  
  stargazer(mods1, digits = 2, header = FALSE, se = lapply(mods1, calcSEs2),
            no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
            type = "text",
            keep = c("mps_emission_sales_est", "mps_emission_mktcap_est",
                     "mps_log_emissions_est"))
  
  
  #coef_print <- sapply(mods2, function(x) coef(x)[2])
  #se_print <- sapply(mods2, function(x) calcSEs2(x)[2])
  
  #paste(round(coef_print, 2), collapse = "&")
  #paste(round(se_print, 2), collapse = "&")
  
  stargazer(mods2, digits = 2, header = FALSE, se = lapply(mods2, calcSEs2),
            no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
            type = "text",
            keep = c("mps_emission_mktcap", "mps_emission_sales", 
                     "mps_log_emissions"))
  
  #coef_print <- sapply(mods3, function(x) coef(x)[2])
  #se_print <- sapply(mods3, function(x) calcSEs2(x)[2])
  
  #paste(round(coef_print, 2), collapse = "&")
  #paste(round(se_print, 2), collapse = "&")
  
  stargazer(mods3, digits = 2, header = FALSE, se = lapply(mods3, calcSEs2),
            no.space = TRUE, omit.stat = c("f", "rsq", "ser"), 
            type = "text",
            keep = c("mps_emissionscores", "mps_escores"))
