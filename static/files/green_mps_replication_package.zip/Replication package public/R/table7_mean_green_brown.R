
source("R/setup.R")
source("R/functions.R")

load("output/european_data_mps.RData")

# Yearly data
yearly_data <- data %>%  filter(!is.na(emission_sales_est)) %>%
  select(Year, RIC, ind_num12, emission_sales_est,
         size_mcap, bookmarket, book_leverage, 
         profitability, tangibility1, cash_asset1,
         age, Beta, cashflow_asset1) %>%
  distinct() %>%
  mutate(profitability = profitability * 100,
         cashflow_asset1 = cashflow_asset1 * 100) %>%
  filter(Year == 2021)

# Estimate green and brown groups without and across industry
yearly_data <- yearly_data %>% 
  mutate(median_emission = quantile(yearly_data $ emission_sales_est, probs = 0.5, na.rm = TRUE)) %>%
  group_by(ind_num12) %>%
  mutate(ind_median_emission = quantile(emission_sales_est, probs = 0.5, na.rm = TRUE)) %>% 
  ungroup() %>%
  mutate(type = ifelse(emission_sales_est <= median_emission, "green", "brown"),
         type_ind = ifelse(emission_sales_est <= ind_median_emission, "green", "brown"))

# Estimate green and brown groups within and across industry

# Mean for across industries
mean1 <- yearly_data %>%
  group_by(type) %>%
  summarise(across(c(size_mcap:cashflow_asset1), ~mean(.x, na.rm = TRUE))) %>%
  pivot_longer(cols = size_mcap:cashflow_asset1) %>%
  pivot_wider(names_from = "type", values_from = "value")

nr_obs1 <- yearly_data %>%
  group_by(type) %>%
  summarise(across(c(size_mcap:cashflow_asset1), ~length(na.omit(.x)))) %>%
  ungroup() %>%
  pivot_longer(cols = size_mcap:cashflow_asset1) %>%
  pivot_wider(names_from = "type", values_from = "value")

# Mean for within industries
mean2 <- yearly_data %>% filter(!is.na(emission_sales_est)) %>%
  group_by(type_ind) %>%
  summarise(across(c(size_mcap:cashflow_asset1), ~mean(.x, na.rm = TRUE))) %>%
  pivot_longer(cols = size_mcap:cashflow_asset1) %>%
  pivot_wider(names_from = "type_ind", values_from = "value")

nr_obs2 <- yearly_data %>%
  group_by(type_ind) %>%
  summarise(across(c(size_mcap:cashflow_asset1), ~length(na.omit(.x)))) %>%
  ungroup() %>%
  pivot_longer(cols = size_mcap:cashflow_asset1) %>%
  pivot_wider(names_from = "type_ind", values_from = "value")

# Custom function to extract t-test results
t_test_stats <- function(data, var, group_var) {
  test <- t.test(data[[var]] ~ data[[group_var]])
  # Return a named list with statistics of interest
  return(tibble(
    t_value = test$statistic
  ))
}

# Get t statistics
t_stat <- yearly_data %>%
  pivot_longer(cols = c(size_mcap:cashflow_asset1), names_to = "name") %>%
  group_by(name) %>%
  nest() %>%
  mutate(t_test1 = map(data, ~t_test_stats(.x, "value", "type")),
         t_test2 = map(data, ~t_test_stats(.x, "value", "type_ind"))) %>%
  unnest(cols = c(t_test1, t_test2), names_sep = "check_unique⁠⁠") %>%
  select(-data)

final_table <- mean1 %>% inner_join(mean2, by = "name") %>%
  inner_join(t_stat, by = "name") %>%
  relocate(`t_test1check_unique⁠⁠t_value`, .before = brown.y)
  #inner_join(nr_obs1, by = "name") %>%
  #inner_join(nr_obs2, by = "name")
  
names(final_table) <- c("variables",
                        "brown",
                        "green",
                        "t_stat",
                        "brown_ind",
                        "green_ind",
                        "t_stat_ind")

final_table %>% mutate(across(brown:t_stat_ind, ~ round(.x, 2)),
                       t_stat = as.numeric(t_stat),
                       t_stat_ind = as.numeric(t_stat_ind)) %>%
  stargazer(summary = FALSE, digits = 2,
            rownames = FALSE, type = "text")

