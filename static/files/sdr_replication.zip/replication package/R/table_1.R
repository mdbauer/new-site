## calculate term structure of SDRs based on estimates of UC model for real rate

rm(list=ls())
graphics.off()
year1 <- 1990
year2 <- 2019

## our data
tbl <- matrix(NA, 3, 6)
rownames(tbl) <- c("UC model",
                   "AR model, break",
                   "AR model, learning")
colnames(tbl) <- c(year1, year2, "Change",
                   year1, year2, "Change")
files <- c("results/sdr_uc_y1.RData",
           "results/sdr_uc_y10.RData",
           "results/sdr_meanshift_y1.RData",
           "results/sdr_meanshift_y10.RData",
           "results/sdr_ar3_expon_y1.RData",
           "results/sdr_ar3_expon_y10.RData")
n <- 1
for (i in 1:3) {
    for (j in 1:2) {
        load(files[n])
        tbl[i, (j-1)*3+(1:3)] <- c(rstar_old, rstar_new, rstar_new - rstar_old)
        n <- n+1
    }
}
print(round(tbl,1))

