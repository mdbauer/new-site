## plot different term structures of SDRs across models

rm(list=ls())
graphics.off()
year1 <- 1990
year2 <- 2019

N <- 400
mats <- 1:N
yrange <- c(0,4.2)

dev.new()
par(mfrow=c(3,2), mar=c(3,3,2,.5), mgp=c(2,.6,0))
cols <- c("gray", "black")
## UC 1y
load("results/sdr_uc_y1.RData")
plot(mats, y1, type="l", lwd=2, ylim=yrange, xlab="", ylab="Discount rate (percent)", col=cols[1], main="UC model, 1y rate", font.main=1, cex.main=1)
lines(mats, y2, lwd=2, col=cols[2])
abline(h=rstar_old, lty=2, lwd=2, col=cols[1])
abline(h=rstar_new, lty=2, lwd=2, col=cols[2])
legend("topright", legend=c(year1, year2), lwd=2, col=cols)
## UC 10y
load("results/sdr_uc_y10.RData")
plot(mats, y1, type="l", lwd=2, ylim=yrange, xlab="", ylab="", col=cols[1], main="UC model, 10y rate", font.main=1, cex.main=1)
lines(mats, y2, lwd=2, col=cols[2])
abline(h=rstar_old, lty=2, lwd=2, col=cols[1])
abline(h=rstar_new, lty=2, lwd=2, col=cols[2])
## AR break, 1y
load("results/sdr_meanshift_y1.RData")
plot(mats, y1, type="l", lwd=2, ylim=yrange, xlab="", ylab="Discount rate (percent)", col=cols[1], main="AR model, break, 1y rate", font.main=1, cex.main=1)
lines(mats, y2, lwd=2, col=cols[2])
abline(h=rstar_old, lty=2, lwd=2, col=cols[1])
abline(h=rstar_new, lty=2, lwd=2, col=cols[2])
## AR break, 10y
load("results/sdr_meanshift_y10.RData")
plot(mats, y1, type="l", lwd=2, ylim=yrange, xlab="", ylab="", col=cols[1], main="AR model, break, 10y rate", font.main=1, cex.main=1)
lines(mats, y2, lwd=2, col=cols[2])
abline(h=rstar_old, lty=2, lwd=2, col=cols[1])
abline(h=rstar_new, lty=2, lwd=2, col=cols[2])
## AR(3) exponential learning, 1y
load("results/sdr_ar3_expon_y1.RData")
plot(mats, y1, type="l", lwd=2, ylim=yrange, xlab="Horizon (years)", ylab="Discount rate (percent)", col=cols[1], main="AR model, learning, 1y rate", font.main=1, cex.main=1)
lines(mats, y2, lwd=2, col=cols[2])
abline(h=rstar_old, lty=2, lwd=2, col=cols[1])
abline(h=rstar_new, lty=2, lwd=2, col=cols[2])
## AR(3) exponential learning, 10y
load("results/sdr_ar3_expon_y10.RData")
plot(mats, y1, type="l", lwd=2, ylim=yrange, xlab="Horizon (years)", ylab="", col=cols[1], main="AR model, learning, 10y rate", font.main=1, cex.main=1)
lines(mats, y2, lwd=2, col=cols[2])
abline(h=rstar_old, lty=2, lwd=2, col=cols[1])
abline(h=rstar_new, lty=2, lwd=2, col=cols[2])


