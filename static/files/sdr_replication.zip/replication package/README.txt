# Replication package for "The Rising Cost of Climate Change: Evidence from the
# Bond Market" by M. Bauer and G. Rudebusch, Review of Economics and Statistics

This replication package contains all code and data files required to produce
the two figures and two tables in the paper.

In case of questions, please contact Michael Bauer at michael.d.bauer@gmail.com

The Online Appendix of the paper is available at: https://www.michaeldbauer.com/files/sdr_appendix.pdf

## Data files

- GS1.csv -- one-year constant-maturity Treasury yield from FRED
- GS10.csv -- ten-year constant-maturity Treasury yield from FRED
- HISTDATA_FRBUS.TXT -- data package for FRB/US model of the Federal Reserve Board
  - See https://www.federalreserve.gov/econres/us-models-package.htm
- MedianGrowthRate_CPI.csv -- median CPI inflation expectation from Livingston survey
  - See https://www.philadelphiafed.org/surveys-and-data/real-time-data-research/livingston-historical-data
- r* estimates from literature, for references see Online Appendix 
  - rstar_delnegro.csv -- Del Negro et al. (2017)
  - rstar_jm.csv -- Johannsen and Mertense (2016)
  - rstar_kiley.csv -- Kiley (2020)
  - rstar_lw (2016) -- Laubach and Williams (2016)
  - Note: These are all *smoothed estimates* based on the state space models in these published paper.
- Damage profiles for DICE models from the literature, for details see the paper and the Online Appendix
  - dice_2016_damages.csv -- DICE-2016 model (Nordhaus, 2017)
  - dice_newell_pizer_damages.csv -- DICE-94 model (Nordhaus, 1994) used in Newell and Pizer (2003)
  - dice_dfg_damages.csv -- DICE-Fair-Geoffroy model of Dietz et al. (2020)
  - dice_haensel_damages.csv -- DICE model of Haensel et al. (2020)

## Software

R version: 4.1.0

R packages:
- dplyr (1.0.7)
- dynlm (0.3-6)
- sandwich (3.0-1)
- KFAS (1.4.5)

## Instructions for replicators

- The individual replication files should be run in the order they are listed
  below, because intermediate results are written to the results folder.

- The file setup.R makes sure the relevant R packages are installed, and should
  be executed once before running the replication code.

- The R code assumes that the working directory is the root folder. The code
  files can be run using source commands as follows:

    source("R/estimate_uc.R")

## Replication code files

Run these files in the order they are listed.

- estimate_uc.R
  - Estimates the UC model.
  - Should be run once for 1y rate and once for 10y rate, commenting out appropriate lines in the beginning.
  - Saves estimation results to results folder.

- figure_1.R produces Figure 1
  
- sdr_uc.R
  - Calculates term structures of SDRs for UC model.
  - Should be run once for 1y rate and once for 10y rate, commenting out appropriate lines in the beginning.
  - Saves term structures to results folder.

- ar_meanshift.R
  - Estimates AR model with break in mean and calculate term structures of SDRs.
  - Should be run once for 1y rate and once for 10y rate, commenting out appropriate lines in the beginning.
  - Saves term structures to results folder.

- ar_learning.R
  - Estimates AR model with exponential smoothing/learning and calculate term structures of SDRs.
  - Should be run once for 1y rate and once for 10y rate, commenting out appropriate lines in the beginning.
  - Saves term structures to results folder.

- table_1.R produces Table 1

- figure_2.R produces Figure 2

- scc.R
  - Calculate the estimates of the social cost of carbon.
  - Requires as input term structures of SDRs in results folder (produced by code files listed above) and DICE model damages in data folder.
  - Should be run once for each DICE model, commenting out appropriate lines in the beginning.
  - Produces Table 2.

## Utility code files

These files contain functions that are used by the main code files.

- data_fns.R -- functions to load data
- uc_fns.R -- functions for estimation of UC model
- sdr_fns.R -- functions for generating term structures of SDRs using simulation
