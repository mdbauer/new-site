# Replication files for Bauer and Rudebusch (2016, RoF)

Please cite as:

Bauer, Michael D., and Glenn D. Rudebusch. "Resolving the spanning puzzle in
macro-finance term structure models." Review of Finance 21.2 (2016): 511-553.

Available here:
https://academic.oup.com/rof/article-abstract/21/2/511/2670354

If you have questions, please contact Michael Bauer at michael.bauer@sf.frb.org.

## Estimation of term structure models

The estimation results used in the published version of the paper are in the
folder `estimates` with the filename post-fix `published`.

If you want to re-estimate the term structure models yourself:
- For yields-only model, use `est_jsz.r`
- For spanned macro-finance model, use `est_jls.r`
- For unspanned macro-finance model, use `est_jps.r`
The results will be saved in folder `estimates`

## Tables and Figures

- Table 3: `test_knife.r`
- Tables 4 and 6: `regressions.r`
- Tables 1, 2, 5, 7, 8: `results.r`

- Figure 1: `regressions.r`
- Figures 2 and 3: `results.r`

- Appendix:
  - Tables B.1 and B.2: `tables_estimates.r`
  - Tables C.1, C.2, C.3, D.1: `results.r`
