## estimate unspanned-macro-risk (UMR) models

remove(list=ls())
set.seed(616)
source("R/jsz_fns.r")
source("R/jps_fns.r")
source("R/data_fns.r")
source("R/util_fns.r")

R <- 3
N <- R+2

### estimate JPS model with GRO/INF
cat("## GRO/INF\n")
loadDTSMdata(flag.jpsmacro=TRUE)
pars <- estJPS(Y, M.o, W, R, mats, gamma=rep(1, R*(N+1)))
cat("optimal LLK:", pars$llk, "\n")
est.llk <- jps.llk(Y, M.o, W, R, KQ.XX=diag(pars$lamQ), Omega.Z = pars$Omega.Z, mats=mats, dt=1)
cat("check       ", -sum(est.llk$llk), "\n")
save(pars, est.llk, Y, W, M.o, R, N, mats,
     file=paste("estimates/jps_gro_R", R, ".RData", sep=""))

### estimate JPS model UGAP/Core PCE
cat("## UGAP/CPI\n")
loadDTSMdata(flag.jpsmacro=FALSE)
pars <- estJPS(Y, M.o, W, R, mats)
cat("optimal LLK:", pars$llk, "\n")
est.llk <- jps.llk(Y, M.o, W, R, KQ.XX=diag(pars$lamQ), Omega.Z = pars$Omega.Z, mats=mats, dt=1)
cat("check       ", -sum(est.llk$llk), "\n")
save(pars, est.llk, Y, W, M.o, R, N, mats,
     file=paste("estimates/jps_ugap_R", R, ".RData", sep=""))




