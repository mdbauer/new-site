% Panel regressions of term premium estimates on measures of uncertainty and the business cycle
% Bauer, Rudebusch, Wu (2014, AER) Comment on ``Term Premia and Inflation Uncertainty: Empirical Evidence from an International Panel Dataset''
% Table 3, table 4
%
% This code is based on MATLAB code provided to us by Jonathan Wright (maketable5.m).

clear;

%% load macro data
% inflation dispersion
m=xlsread('data/surveydata.xls','infdisp','C2:L238');
for i=1:10;
g=find(isnan(m(:,i))==0);
dispersion_inf(1:g(1)+10,i)=nan;
for j=g(1)+11:237;
    m0=m(j-11:j,i); m0=m0(find(isnan(m0)==0));
    dispersion_inf(j,i)=mean(m0);
end; 
end;
dispersion_inf(63:83,9)=nan;  %missings for Australia
dispersion_inf=dispersion_inf(5:end,:);  %Start in January 1990
dispersion_inf=dispersion_inf([3:3:233]',:); %And make quarterly

% growth dispersion
m=xlsread('data/surveydata.xls','growthdisp','C2:L238');
for i=1:10;
g=find(isnan(m(:,i))==0);
dispersion_gr(1:g(1)+10,i)=nan;
for j=g(1)+11:237;
    m0=m(j-11:j,i); m0=m0(find(isnan(m0)==0));
    dispersion_gr(j,i)=mean(m0);
end; 
end;
dispersion_gr(63:83,9)=nan;  %missings for Australia
dispersion_gr=dispersion_gr(5:end,:);  %Start in January 1990
dispersion_gr=dispersion_gr([3:3:233]',:); %And make quarterly

% ECRI dates
ecri=xlsread('data/Ecridates.xls','Sheet1','B362:J594');
ecri=ecri(:,[9 8 3 4 2 5 7 1 6]);  %order the right way
ecri=ecri([3:3:233]',:); %And make quarterly

% standard deviation of long-run component
load 'data/sd_eps';
sd_eps=sd_eps(:,[10 6 4 5 2 7 9 3 1 8]);  %order the right way
sd_eps=sd_eps(120:end,:);           %start in 1990Q1

[GDP, CLI] = load_macro();

%% which term premium?

tp = load_tp('tp2_ols.xls');  disp('*** OLS TERM PREMIUM ***');
%tp = load_tp('tp2_bc2.xls');  disp('*** BC TERM PREMIUM ***');

%% Table 3 -- Regressions of term premium estimates on measures of uncertainty

[bhat,vcov]=panelreg(tp,1,sd_eps);
bootp=blockbootstrap(tp,1,4,sd_eps);
disp('RHS Variable: Permanent component');
disp([bhat sqrt(diag(vcov)) bootp]);

[bhat,vcov]=panelreg(tp,1,dispersion_inf);
bootp=blockbootstrap(tp,1,4,dispersion_inf);
disp('RHS Variable: Inflation dispersion');
disp([bhat sqrt(diag(vcov)) bootp]);

[bhat,vcov]=panelreg(tp,1,dispersion_gr);
bootp=blockbootstrap(tp,1,4,dispersion_gr);
disp('RHS Variable: Growth dispersion');
disp([bhat sqrt(diag(vcov)) bootp]);

[bhat,vcov]=panelreg(tp,1,dispersion_inf,dispersion_gr);
bootp=blockbootstrap(tp,1,4,dispersion_inf,dispersion_gr);
disp('RHS Variable: All Dispersion');
disp([bhat sqrt(diag(vcov)) bootp]);

[bhat,vcov]=panelreg([tp(:,1:5) tp(:,7:end)],1,[dispersion_inf(:,1:5) dispersion_inf(:,7:end)],[dispersion_gr(:,1:5) dispersion_gr(:,7:end)],ecri);
bootp=blockbootstrap([tp(:,1:5) tp(:,7:end)],1,4,[dispersion_inf(:,1:5) dispersion_inf(:,7:end)],[dispersion_gr(:,1:5) dispersion_gr(:,7:end)],ecri);
disp('RHS Variable: infl. disp, gr. disp, recession dummy');
disp([bhat sqrt(diag(vcov)) bootp]);

[bhat,vcov]=panelreg([tp(:,1:5) tp(:,7:end)],1,[sd_eps(:,1:5) sd_eps(:,7:end)],[dispersion_gr(:,1:5) dispersion_gr(:,7:end)],ecri);
bootp=blockbootstrap([tp(:,1:5) tp(:,7:end)],1,4,[sd_eps(:,1:5) sd_eps(:,7:end)],[dispersion_gr(:,1:5) dispersion_gr(:,7:end)],ecri);
disp('RHS Variable:  PERM-UCSD, gr. disp., recession dummy');
disp([bhat sqrt(diag(vcov)) bootp]);

%% Table 4 -- Cyclicality

[bhat,vcov]=panelreg([tp(:,[1:5, 7:end])],1,ecri);
bootp=blockbootstrap([tp(:,1:5) tp(:,7:end)],1,4,ecri);
disp('RHS Variable: recession dummy');
disp([bhat sqrt(diag(vcov)) bootp]);

[bhat,vcov]=panelreg(tp,1,GDP);
bootp=blockbootstrap(tp,1,4,GDP);
disp('RHS Variable: GDP growth QoQ');
disp([bhat sqrt(diag(vcov)) bootp]);

[bhat,vcov]=panelreg(tp,1,CLI);
bootp=blockbootstrap(tp,1,4,CLI);
disp('RHS Variable: CLI');
disp([bhat sqrt(diag(vcov)) bootp]);
