% Analyze cyclical behavior of term premia in each country
% Bauer, Rudebusch, Wu (2014, AER) Comment on ``Term Premia and Inflation Uncertainty: Empirical Evidence from an International Panel Dataset''
% Table 5

clear;
cvec={'U.S.','Japan','Germany','U.K.', 'Canada', 'Norway','Sweden','Switzerland', 'Australia', 'New Zealand'};

%Read in surveys
m=xlsread('data/surveydata.xls','infdisp','C2:L238');
for i=1:10;
    g=find(isnan(m(:,i))==0);
    dispersion_inf(1:g(1)+10,i)=nan;
    for j=g(1)+11:237;
        m0=m(j-11:j,i); m0=m0(find(isnan(m0)==0));
        dispersion_inf(j,i)=mean(m0);
    end;
end;
dispersion_inf(63:83,9)=nan;  %missings for Australia
dispersion_inf=dispersion_inf(5:end,:);  %Start in January 1990
dispersion_inf=dispersion_inf([3:3:233]',:); %And make quarterly

m=xlsread('data/surveydata.xls','growthdisp','C2:L238');
for i=1:10;
    g=find(isnan(m(:,i))==0);
    dispersion_gr(1:g(1)+10,i)=nan;
    for j=g(1)+11:237;
        m0=m(j-11:j,i); m0=m0(find(isnan(m0)==0));
        dispersion_gr(j,i)=mean(m0);
    end;
end;
dispersion_gr(63:83,9)=nan;  %missings for Australia
dispersion_gr=dispersion_gr(5:end,:);  %Start in January 1990
dispersion_gr=dispersion_gr([3:3:233]',:); %And make quarterly

% Read in standard deviation of long-run component
load 'data/sd_eps';
sd_eps=sd_eps(:,[10 6 4 5 2 7 9 3 1 8]);  %order the right way
sd_eps=sd_eps(120:end,:);           %start in 1990Q1

%Read in ECRI dates
ecri=xlsread('data/Ecridates.xls','Sheet1','B362:J594');
ecri=ecri(:,[9 8 3 4 2 5 7 1 6]);  %order the right way
ecri=ecri([3:3:233]',:); %And make quarterly
T = length(ecri(:,1));
ecri = [ecri(:, 1:5), zeros(T,1), ecri(:, 6:9)];

[GDP, CLI] = load_macro();

tp_ols = load_tp('tp2_ols.xls');
tp_bc = load_tp('tp2_bc2.xls');

%% country-by-country analysis of cyclical behavior

b_out = zeros(10, 3*2)*NaN;
p_out = zeros(10, 3*2)*NaN;
R2_out = zeros(10, 3*2)*NaN;

nw_lags = 4;

% for each cyclical indicator
for i=1:3
    % for each country
    for k=1:10
        % construct regressor matrix
        switch i
            case 1
                Xdat = [ones(T,1), ecri(:,k)];
            case 2
                Xdat = [ones(T,1), GDP(:,k)];
            case 3
                Xdat = [ones(T,1), CLI(:,k)];
        end
        
        col = (i-1)*2+1;  % two columns for each cyclical indicator
        
        % no recession indicator for Norway
        if (k==6)&&(i==1); continue; end;
        
        % OLS term premium
        ydat = tp_ols(:,k);
        [bhat, se] = nw_na(ydat, Xdat, nw_lags);
        b_out(k,col) = bhat(2);
        p_out(k,col) = (1-tcdf(abs(bhat(2)/se(2)),T-2))*2;
        R2_out(k,col) = Rsquared_na(ydat, Xdat);
        
        % BC term premium
        ydat = tp_bc(:,k);
        [bhat, se] = nw_na(ydat, Xdat, nw_lags);
        b_out(k,col+1) = bhat(2);
        p_out(k,col+1) = (1-tcdf(abs(bhat(2)/se(2)),T-2))*2;
        R2_out(k,col+1) = Rsquared_na(ydat, Xdat);
    end
end

fprintf(' && Rec. dummy  &  GDP (QoQ)  & CLI   \\\\ \n');
for i=1:3; fprintf(' & OLS  &  BC '); end; fprintf('\\\\ \n');
for k=1:10
    fprintf('%12s ', cvec{k});
    fprintf('& Coef.');
    fprintf('& %4.2f ', b_out(k,:)); fprintf('\\\\ \n');
    fprintf('             ');
    fprintf('& $p$  ');
    fprintf('&(%4.2f)', p_out(k,:)); fprintf('\\\\ \n');
    fprintf('             ');
    fprintf('& $R^2$');
    fprintf('&%4.1f\\%%', 100*R2_out(k,:)); fprintf('\\\\ \n');
    fprintf('\\hline \n');
end