function [R2] = Rsquared_na(ydat, Xdat)
% clear NAs and then run Rsquared

    g=isnan(ydat);
    for i=1:size(Xdat,2); g=g+isnan(Xdat(:,i)); end;
    ydat=ydat(find(g==0),:); Xdat=Xdat(find(g==0),:); 
    
    [R2] = Rsquared(ydat, Xdat);
    
end
