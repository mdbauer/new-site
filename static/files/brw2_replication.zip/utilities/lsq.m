function [b, std_err, ssr, adjR2] = lsq(yq,x1)
%     This proc performs an OLS regression of yq on x1
%      output:
% 	b = OLS coefficient estimates
% 	std_err = their standard errors
% 	ssr = sum of squared residuals @ 
global kc;  % parameter to determine whether results should be printed
   n = length(yq); 
   b = x1\yq;
   eps = yq - x1*b;
   [rows, cols] = size(x1);
   sigols = sum(eps.^2)/(rows-cols);
   sigmle = sum(eps.^2)/rows;
   std_err = sigols*inv(x1'*x1);
   std_err = sqrt(diag(std_err));
   if sigmle > 0
       ll = -(n/2)*(1 + log(2*pi)) - (n/2)*log(sigmle);
   else
       ll = NaN;
   end
   
   ssr = eps'*eps;
   if var(yq)>0 
       adjR2 = 1 - sigols / var(yq);
   else
       adjR2 = NaN;
   end
   
 if kc > 1
    disp(['ols see ', num2str(sqrt(sigols))]);
    disp(['mle see ', num2str(sqrt(sigmle))]);
    disp(['ols log likelihood ', num2str(ll)]);
    disp('     coeffs    std errs');
    disp([b, std_err]);
 end
end

