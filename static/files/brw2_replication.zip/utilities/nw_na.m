function [b, s] = nw_na(ydat, Xdat, lag)
% clear NAs and then run nw

    g=isnan(ydat);
    for i=1:size(Xdat,2); g=g+isnan(Xdat(:,i)); end;
    ydat=ydat(find(g==0),:); Xdat=Xdat(find(g==0),:); 
    
    [b, s] = nw(ydat, Xdat, lag);
    
end
