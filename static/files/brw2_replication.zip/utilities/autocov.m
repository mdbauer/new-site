% proc to calculate the jth autocovariance of a vector vee without subtracting mean@
function [cov_vee] = autocov(vee,j_vee)
% 	@ inputs:
% 		vee = (capt x k) matrix, row t is date t obs for vector
% 			whose j_vee th autocovariance is sought @
	[T_vee, cols] = size(vee);
	cov_vee = vee( (j_vee + 1):T_vee,:)'*vee(1:(T_vee - j_vee),:);
	cov_vee = cov_vee/T_vee;
end