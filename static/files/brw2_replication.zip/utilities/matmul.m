function [x] = matmul(a, b)
    % does element-by-element multiplication for matrices 
    % that do not have the same size
    % in GAUSS this works with a.*b but not in Matlab
    
    % input:
    %   a is n x 1
    %   b is n x m
    % output:
    %   x is n x m
    
    [n, m] = size(b);
    x = zeros(n, m);
    for i=(1:n)
        x(i,:) = a(i)*b(i,:);
    end
end