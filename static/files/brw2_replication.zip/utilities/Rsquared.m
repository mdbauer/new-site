function [R2] = Rsquared(yq,x1)
%     This proc calculates the R2 from OLS
   n = length(yq); 
   b = x1\yq;
   eps = yq - x1*b;
   ssr = eps'*eps;
   ydev = yq - mean(yq);
   sst = ydev'*ydev;
   R2 = 1 - ssr/sst;
end

