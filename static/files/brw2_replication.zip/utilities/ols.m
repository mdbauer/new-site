function [bhat,vcov]=ols(x,y);
bhat=inv(x'*x)*x'*y;
[n,p]=size(x);
res=y-(x*bhat);
sigs=sum(res.^2)/(n-p);
vcov=sigs*inv(x'*x);
vcov=sqrt(diag(vcov));
