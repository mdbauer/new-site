function [bhat,vcov]=olswhite(y,x);
%OLS with White standard errors
bhat=inv(x'*x)*x'*y;
res=y-(x*bhat);
[n,p]=size(x);
m1=zeros(p,p);
for i=1:n; m1=m1+((res(i)^2)*(x(i,:)'*x(i,:))); end;
vcov=inv(x'*x)*m1*inv(x'*x)*n/(n-p);
