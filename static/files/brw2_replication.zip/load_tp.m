function tp = load_tp(filename)
% Load term premium estimates for each of ten countries
% Bauer, Rudebusch, Wu (2014, AER) Comment on ``Term Premia and
% Inflation Uncertainty: Empirical Evidence from an International Panel Dataset''
%
% Arguments:
%  filename - path+name of XLS file
%
% Returns:
%  tp - Tx10 matrix with panel of estimated forward term premium

% Sample: 1990Q1-2009Q1 (T=77 obs)

% These term premium estimates were saved by tpestaffine2_new.m

tp1=xlsread(filename,'Baseline','U2:U78');%US
tp2=xlsread(filename,'Baseline','AD2:AD78');%Japan
tp3=xlsread(filename,'Baseline','I2:I78');%Germany
tp4=xlsread(filename,'Baseline','R2:R78');%UK
tp5=xlsread(filename,'Baseline','C2:C78');%Canada
tp6=xlsread(filename,'Baseline','L2:L78');%Norway
tp7=xlsread(filename,'Baseline','O2:O78');%Sweden
tp8=xlsread(filename,'Baseline','F2:F78');%Switzerland
tp9=xlsread(filename,'Baseline','X2:X78');%Australia
tp10=xlsread(filename,'Baseline','AA2:AA78');%New Zealand
tp6=[nan*ones(32,1);tp6]; tp7=[nan*ones(11,1);tp7];
tp=[tp1 tp2 tp3 tp4 tp5 tp6 tp7 tp8 tp9 tp10];