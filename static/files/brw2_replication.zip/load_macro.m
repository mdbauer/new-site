function [GDP, CLI] = load_macro()
% Load panel macro data set 
% Bauer, Rudebusch, Wu (2014, AER) Comment on ``Term Premia and
% Inflation Uncertainty: Empirical Evidence from an International Panel Dataset''
%
% Returns:
%  GDP - quarterly (QoQ) growth of real GDP
%  CLI - composite leading indicator index from OECD

%OECD_countries = {'Australia', 'Canada', 'Germany', 'Japan', 'New Zealand', 'Norway', 'Sweden', 'Switzerland', 'United Kingdom', 'United States'};
country_resort = [10, 4, 3, 9, 2, 6, 7, 8, 1, 5];
% to get the right ordering
% check: disp([cvec', OECD_countries(country_resort)'])

% CLI
CLI = csvread('data_new/oecd_cli.csv', 1, 0);
% order countries the right way
CLI = CLI(:, [1, 1+country_resort]);
% select subsample of quarterly observations
dates = CLI(:,1);
startdate = 199003; enddate = 200903;
year = floor(dates/100);
month = dates-year*100;
smpl = dates>=startdate & dates<=enddate & mod(month,3)==0;
CLI = CLI(smpl, 2:11);

% GDP growth
GDP=xlsread('data_new/oecd_gdp_qoq','C8:L84');
GDP = GDP(:,country_resort);

end
