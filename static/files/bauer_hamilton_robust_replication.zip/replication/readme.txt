Code and data for replication of:
Bauer and Hamilton (2017) "Robust Bond Risk Premia" FRBSF Working Paper 2015-15
http://www.frbsf.org/economic-research/publications/working-papers/2015/wp2015-15.pdf
Version: May 22, 2017

The code, written in R, is sufficiently self-explanatory and self-contained that you should be able to replicate our results simply by following these steps:
1. Unpack the ZIP file into a folder
2. Start an R session
3. Set the working directory to that folder using setwd()
4. Run the code in each of the scripts in the folder, e.g. source("jps.r") 

Note: You may need to install additional R packages, e.g. install.packages("sandwich")

The folder "R" contains files with additional functions that are loaded when the scripts are run.

The folder "data" contains the data we used in each of the six empirical case studies.

Please don't hesitate and let us know if you 
- have questions about the code or data
- have trouble replicating our results
- find errors or omissions
- have suggestions

Please contact:
Michael Bauer
Federal Reserve Bank of San Francisco
101 Market St MS 1130, San Francisco, CA 94105 
415-974-3299
michael.bauer@sf.frb.org


